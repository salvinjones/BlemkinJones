package core

const (
	MainnetChainID = "pandonet"

	MainnetGenesisBlockHash = "0x294191fdd2a46c213dbb34dd61a873a293604080f6d5372a6e005a1673426b7a"

	GenesisBlockHeight = uint64(0)
)
