package metrics

func init() {
	Enabled = true
}
