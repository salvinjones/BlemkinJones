#!/bin/sh

echo "starting"
/bin/pando start --password=qwertyuiop
