package main

import "github.com/pandoprojects/pando/cmd/pandocli/cmd"

func main() {
	cmd.Execute()
}
