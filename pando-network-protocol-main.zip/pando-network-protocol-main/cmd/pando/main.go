package main

import "github.com/pandoprojects/pando/cmd/pando/cmd"

func main() {
	cmd.Execute()
}
